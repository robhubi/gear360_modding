#!/bin/sh

# Start with blinking LED to indicate standby
st led 5 blink
sleep 2

# Read current mode code (e.g., 0x01 = Photo mode)
modecode=$(prefman get 0 0x00004445 b | grep -o "0x..")

# Main loop
while true
do
    if [ "$modecode" = "0x01" ]; then
        # In Photo mode: turn off blinking LED and start shooting
        st led 5 off
        while [ "$modecode" = "0x01" ]
        do
			echo "Shot"
            st key click s2       # Trigger shutter
            sleep 1             # Wait 1000 ms
            modecode=$(prefman get 0 0x00004445 b | grep -o "0x..")
        done
    else
        # Not in Photo mode: keep LED blinking
        st led 5 blink
        sleep 2
        modecode=$(prefman get 0 0x00004445 b | grep -o "0x..")
    fi
done

